﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Emma.Models;

using Emma.Views;
using SQLite;
using Xamarin.Forms;

namespace Emma
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
          
            Task.Delay(300).Wait();
           // potato.Source = ImageSource.FromResource("Emma.Images.Potato.png");
           // potato.IsVisible = false;
         

            
        }

        protected async override void OnAppearing()
        {
            Task.Delay(7000).Wait();
            GIF.IsVisible = false;
            
            await this.Navigation.PushAsync(new HomePage());
            base.OnAppearing();



        }

        public Stream GetStreamFromFile(string filename)
        {
            var assembly = typeof(App).GetTypeInfo().Assembly;

            var stream = assembly.GetManifestResourceStream("Emma.Music." + filename);

            return stream;
        }

    }
}
