﻿using System;
using Xamarin.Forms;
using SQLite;
namespace Emma.Models
{


    public class Memories
    {

        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }


        [MaxLength(255)]
        [Indexed]
        public string Date { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }
        public string Imageload { get; set; }

        public Memories(string _date, string _imageload, string _location, string _description)
        {
            this.Date = _date;
            this.Imageload = _imageload;
            this.Location = _location;
            this.Description = _description;
        }

        public Memories()
        {
        }
    }
}
