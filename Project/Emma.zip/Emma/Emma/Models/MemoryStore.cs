﻿using System;
using Xamarin.Forms;

namespace Emma.Models
{
    public class MemoryStore
    {

        public string DateStore { get; set; }
        public string LocationStore { get; set; }
        public string DescriptionStore { get; set; }
        public ImageSource ImageStore { get; set; }

        public MemoryStore(string _date, ImageSource image, string _location, string _description)
        {
            this.DateStore = _date;
            this.LocationStore = _location;
            this.DescriptionStore = _description;
            this.ImageStore = image;
        }
        public MemoryStore()
        {
        }
    }
}
