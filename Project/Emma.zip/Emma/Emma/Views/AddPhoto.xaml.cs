﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using Emma.Models;
using Java.Time.Format;
using Plugin.Media;
using SQLite;
using Xamarin.Forms;

namespace Emma.Views
{
    public partial class AddPhoto : ContentPage
    {
        string base64memory;
        List<MemoryStore> mems = new List<MemoryStore>();
        private ObservableCollection<Memories> obsmem;
       

        public AddPhoto()
        {
            InitializeComponent();
            flower.Source = ImageSource.FromResource("Emma.Images.flowers.png");
            Submit.FontAttributes = FontAttributes.Bold | FontAttributes.Italic;

        }

        async void Submit_Clicked(System.Object sender, System.EventArgs e)
        {

            await CrossMedia.Current.Initialize();

            if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
            {
                await DisplayAlert("No Camera", ":( No camera available.", "OK");
                return;
            }

            var file = await CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions
            {
                Directory = "Images",
                Name = "Capture.jpg"
            });

            if (file == null)
                return;

            using (MemoryStream ms = new MemoryStream())
            {
                var stream = file.GetStream();
                var bytes = new byte[stream.Length];
                await stream.ReadAsync(bytes, 0, (int)stream.Length);
                base64memory = Convert.ToBase64String(bytes);
                file.Dispose();

            }
            if (locatiolbl.Text == "" && Descrip.Text == "" && _date == null)
            {
                await DisplayAlert("MESSAGE", "Please enter in the Location, Date and Description my POTATO!", "OK");
            }
            else
            {
                var result = await DisplayAlert("Message", "Are you satisfied with the Image", "YES", "NO");

                if (result == true)
                {
                    var databasePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "MyData.db");
                    var db = new SQLiteAsyncConnection(databasePath);
                    var memories = await db.Table<Memories>().ToListAsync();
                    string date = string.Format(_date.Date.ToString("dd/MM/yy"));
                    memories.Add(new Memories(date, base64memory, locatiolbl.Text, Descrip.Text));
                
                    await db.DropTableAsync<Memories>();
                    await db.CreateTableAsync<Memories>();
                    await db.InsertAllAsync(memories);
                    await Navigation.PushAsync(new HomePage());

                }
                else
                {

                    Descrip.Text = "";
                    locatiolbl.Text = "";
                    var result1 = await DisplayAlert("Message", "Would you like to create another entry", "YES", "NO");
                    if (result == true)
                    {

                        return;

                    }
                    else
                        await Navigation.PushAsync(new HomePage());

                }

            }
        }
    }
}