﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Reflection;
using Emma.Models;
using SQLite;
using Xamarin.Forms;

namespace Emma.Views
{

    public partial class ViewImages : ContentPage
    {
        private List<MemoryStore> memos = new List<MemoryStore>();
        private ObservableCollection<Memories> obsmem;
        public ViewImages()
        {
            InitializeComponent();
            var stream = GetStreamFromFile("The Neighbourhood - Scary Love (Audio).mp3");
            var audio = Plugin.SimpleAudioPlayer.CrossSimpleAudioPlayer.Current;
           
            audio.Load(stream);
            audio.Play();
        }
        public Stream GetStreamFromFile(string filename)
        {
            var assembly = typeof(App).GetTypeInfo().Assembly;

            var stream = assembly.GetManifestResourceStream("Emma.Music." + filename);

            return stream;
        }

        protected override async void OnAppearing()
        {

            var databasePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "MyData.db");
            var db = new SQLiteAsyncConnection(databasePath);
            await db.CreateTableAsync<Memories>();
            var memories = await db.Table<Memories>().ToListAsync();
            

            if (memories.Count > 0)
            {
                obsmem = new ObservableCollection<Memories>(memories); 
                for (int i = 0; i < obsmem.Count; i++)
                {

                    ImageSource imagesourceSig = null;
                    byte[] Base64StreamSignature = Convert.FromBase64String(obsmem[i].Imageload);
                    imagesourceSig = ImageSource.FromStream(() => new MemoryStream(Base64StreamSignature));

                    var newlist = new MemoryStore(obsmem[i].Date, imagesourceSig, obsmem[i].Location, obsmem[i].Description);
                    memos.Add(newlist);
                }
                CV.ItemsSource = memos;
            }

            base.OnAppearing();
        }


        void CV_SelectionChanged(System.Object sender, Xamarin.Forms.SelectionChangedEventArgs e)
        {





        }
    }
}