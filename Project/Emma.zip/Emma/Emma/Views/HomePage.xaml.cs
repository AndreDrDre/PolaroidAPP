﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Emma.Models;

using Plugin.Media;
using SQLite;
using Xamarin.Forms;


namespace Emma.Views
{
    public partial class HomePage : ContentPage
    {

        public HomePage()

        {
            InitializeComponent();
            flower.Source = ImageSource.FromResource("Emma.Images.flowers.png");
            Memories.FontAttributes = FontAttributes.Bold | FontAttributes.Italic;
            takephoto.FontAttributes = FontAttributes.Bold | FontAttributes.Italic;
            slide.FontAttributes = FontAttributes.Bold | FontAttributes.Italic;
            

        }
        
        async void SlideShow_Clicked(System.Object sender, System.EventArgs e)
        {

            await Navigation.PushAsync(new SlideShow());
        }

        public Stream GetStreamFromFile(string filename)
        {
            var assembly = typeof(App).GetTypeInfo().Assembly;
            var stream = assembly.GetManifestResourceStream("Emma.Music." + filename);
            return stream;
        }

        public Stream GetStreamFromFilePhoto(string filenamephoto)
        {
            var assembly = typeof(App).GetTypeInfo().Assembly;
            var stream = assembly.GetManifestResourceStream(filenamephoto);
            return stream;
        }


        protected override async void OnAppearing()
        {

            var stream = GetStreamFromFile("The Neighbourhood - Scary Love (Audio).mp3");
            var audio = Plugin.SimpleAudioPlayer.CrossSimpleAudioPlayer.Current;
            audio.Load(stream);
            audio.Play();


            //Create database

            var databasePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "MyData.db");
            var db = new SQLiteAsyncConnection(databasePath);
            await db.CreateTableAsync<Memories>();

    

            base.OnAppearing();
        }
           

        

       async void View_Clicked(System.Object sender, System.EventArgs e)
        {

            await Navigation.PushAsync(new ViewImages());

        }

       private async void TakePhoto_Clicked(System.Object sender, System.EventArgs e)
        {


            await Navigation.PushAsync(new AddPhoto());


           
        }

       
    }
}
