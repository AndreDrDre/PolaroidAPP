﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Emma.Models;
using SQLite;
using Xamarin.Forms;

namespace Emma.Views
{
    public partial class SlideShow : ContentPage
    {
        private List<MemoryStore> mems = new List<MemoryStore>();
        private ObservableCollection<Memories> obsmem;

       
        public IEnumerable MemoryList { get; private set; }

        public SlideShow()
        {
            InitializeComponent();
           
            flower.Source = ImageSource.FromResource("Emma.Images.flowers.png");
            var stream = GetStreamFromFile("The Neighbourhood - Scary Love (Audio).mp3");
            var audio = Plugin.SimpleAudioPlayer.CrossSimpleAudioPlayer.Current;
            audio.Load(stream);
            audio.Play();

        }


        protected async override void OnAppearing()
        {
            var databasePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "MyData.db");
            var db = new SQLiteAsyncConnection(databasePath);
            await db.CreateTableAsync<Memories>();

            var memories = await db.Table<Memories>().ToListAsync();
           

            if (memories.Count > 0)
            {
                obsmem = new ObservableCollection<Memories>(memories);
                for (int i = 0; i < obsmem.Count; i++)
                {
                    ImageSource imagesourceSig = null;
                    byte[] Base64StreamSignature = Convert.FromBase64String(obsmem[i].Imageload);
                    imagesourceSig = ImageSource.FromStream(() => new MemoryStream(Base64StreamSignature));
                    var newlist = new MemoryStore(obsmem[i].Date, imagesourceSig, obsmem[i].Location, obsmem[i].Description);
                    mems.Add(newlist);
                }

                SlideShowList.ItemsSource = mems;
            }

            //This is the slide show

            if (memories.Count > 0)
            {

                Device.StartTimer(TimeSpan.FromSeconds(5), (Func<bool>)(() =>
                    {
                        SlideShowList.Position = (SlideShowList.Position + 1) % mems.Count;   
                        return true;
                    }));

            }
            base.OnAppearing();  
        }

       public Stream GetStreamFromFile(string filename)
        {
            var assembly = typeof(App).GetTypeInfo().Assembly;

            var stream = assembly.GetManifestResourceStream("Emma.Music." + filename);

            return stream;
        }

    }
}
