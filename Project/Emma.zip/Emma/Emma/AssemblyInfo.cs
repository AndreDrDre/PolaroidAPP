using Xamarin.Forms.Xaml;
using Xamarin.Forms;

[assembly: ExportFont("Polaroid-Italic.ttf", Alias = "Polaroid")]

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]